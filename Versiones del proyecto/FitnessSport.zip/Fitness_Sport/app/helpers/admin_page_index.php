<?php
//Clase para definir las plantillas de las páginas web del sitio privado
class admin_page_index {
    //Método para imprimir el encabezado y establecer el titulo del documento
    public static function headerTemplate($title) {
        print('
            <!DOCTYPE html>
            <html lang="es">
            <head>
                <!--Se establece la codificación de caracteres para el documento-->
                <meta charset="utf-8">
                <!--Se importa la fuente de iconos de Google-->
                <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
                <!--Se importan los archivos CSS-->
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
                <link type="text/css" rel="stylesheet" href="../../resources/css/dashboard_styles.css" />
                <!--Se informa al navegador que el sitio web está optimizado para dispositivos móviles-->
                <meta name="viewport" content="width=device-width, initial-scale=1.0" />
                <!--Título del documento-->
                <title>Administradores - '.$title.'</title>
            </head>
            
            <body>
                <!--Encabezado del documento-->
                <!--Encabezado del documento-->
                <header>
                <nav class=" cyan darken-4">
                <div class="nav-wrapper">
                  <a href="#!" class="brand-logo"></a><img  src="../../resources/img/3.png" height="55"></a>
                  <a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
                  <ul class="right hide-on-med-and-down">
                    <li><a href="IndexUsuario.php">Principal</a></li>
                    <li><a href="Administrar_Empleado.php">Administrar Empleado</a></li>
                    <li><a href="Inventario.php">Inventario</a></li>
                    <li><a href="Producto.php">Producto</a></li>
                    <li class="nav-item active"><a class="waves-effect waves-light btn modal-trigger" href="index.php"><i class="material-icons right">power_settings_new</i>Cerrar sesión</a></li>
                  </ul>
                </div>
              </nav>
            
              <ul class="sidenav" id="mobile-demo">
              <i class="material-icons right">home</i><li><a href="IndexUsuario.php">Principal</a></li>
              <i class="material-icons right">person_add</i><li><a href="Administrar_Empleado.php">Administrar Empleado</a></li>
              <i class="material-icons right">filter_frames</i><li><a href="Inventario.php">Inventario</a></li>
              <i class="material-icons right">shopping_basket</i><li><a href="Producto.php">Producto</a></li>
              <li class="nav-item active"><a class="waves-effect waves-light btn modal-trigger" href="index.php"><i class="material-icons right">power_settings_new</i>Cerrar sesión</a></li>
              </ul>
                    
                </header>
                <!--Contenido principal del documento-->
                <main>
        ');
    }

    //Método para imprimir el pie y establecer el controlador del documento
    public static function footerTemplate($controller) {
        print('
                </main>
                <!--Pie del documento-->
                <footer class="page-footer cyan darken-4">
                <div class="container">
                <div class="row">
                    <div class="col l6 s12">
                        <h5 class="white-text">Derechos de autor reservados para la compañia</h5>
                        <p class="grey-text text-lighten-4">Razon social:  Fitness Sports, s.a. de c.v

                        Número de identificación tributaria (NIT):  0114-900803-101-5
                        
                        Dirección: 9ª calle poniente #3935. Col. Escalon, San Salvador.
                        
                        © 2020 Fitness Sport | Fitnes_Sport.com.sv | Todos los derechos reservados.</p>
                    </div>
                    <div class="col l4 offset-l2 s12">
                        <h5 class="white-text">Nuestras redes sociales</h5>
                        <ul>
                        <li><a class="white-text" href="https://www.facebook.com/Fitness-Sport-106849218143648">Facebook</a><i class="material-icons left">facebook</i></li>                              
                        <li><a class="white-text" href="https://www.instagram.com/fitnesssport212/">Instagram</a><i class="material-icons left">phone_android</i></li>
                        <li><a class="white-text" href="https://twitter.com/Fitness24651901">Twitter</a><i class="material-icons left">people_outline</i></li> 
                        </ul>
                    </div>
                </div>
            </div>
                    <div class="footer-copyright">
                        <div class="container">
                            © 2020 Copyright Text
                            <a class="grey-text text-lighten-4 right" href="#!"></a>
                        </div>
                    </div>
                </footer>
                <!--Importación de archivos JavaScript al final del cuerpo para una carga optimizada-->
                <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
                <script src="../../app/controllers/dashboard/'.$controller.'"></script>
            </body>
            </html>
        ');
    }
}
?>