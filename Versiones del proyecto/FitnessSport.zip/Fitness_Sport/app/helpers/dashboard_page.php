<?php
//Clase para definir las plantillas de las páginas web del sitio privado
class Dashboard_Page {
    //Método para imprimir el encabezado y establecer el titulo del documento
    public static function headerTemplate($title) {
        print('
            <!DOCTYPE html>
            <html lang="es">
            <head>
                <!--Se establece la codificación de caracteres para el documento-->
                <meta charset="utf-8">
                <!--Se importa la fuente de iconos de Google-->
                <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
                <!--Se importan los archivos CSS-->
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
                <link type="text/css" rel="stylesheet" href="../../resources/css/dashboard_styles.css" />
                <!--Se informa al navegador que el sitio web está optimizado para dispositivos móviles-->
                <meta name="viewport" content="width=device-width, initial-scale=1.0" />
                <!--Título del documento-->
                <title>Administradores - '.$title.'</title>
            </head>
            
            <body>
                <!--Encabezado del documento-->
                <header>
                    <nav class="cyan darken-4" role="navigation">
                    <div class="nav-wrapper container"><a id="logo-container" href="#" class="brand-logo"></a>
                    <ul class="left hide-on-med-and-down">
                        <li><a href="Principal.php">Principal</a></li>
                        <li><a href="Futbol.php">Administrar Empleado</a></li>
                        <li><a href="Basquetbol.php">Inventario</a></li>
                        <li><a href="Tenis.php">Producto</a></li>                    
                        <li><a class="waves-effect waves-light btn modal-trigger" href="#modal6">Cerrar Sesion</a></li>
                    </ul>
                    </div>
                    </nav>

                    <ul id="slide-out" class="sidenav">
                        <li>
                            <div class="user-view">
                                <div class="background">
                                    <img src="../../resources/img/background.png">
                                </div>
                                <a href="#user"><img class="circle" src="../../resources/img/users/foto.png"></a>
                                <a href="#name"><span class="white-text name">John Doe</span></a>
                                <a href="#email"><span class="white-text email">jdandturk@gmail.com</span></a>
                            </div>
                        </li>
                        <li><a href="#!"><i class="material-icons">cloud</i>First Link With Icon</a></li>
                        <li><a href="#!">Second Link</a></li>
                        <li>
                            <div class="divider"></div>
                        </li>
                        <li><a class="subheader">Subheader</a></li>
                        <li><a class="waves-effect" href="#!">Third Link With Waves</a></li>
                    </ul>
                </header>
                <!--Contenido principal del documento-->
                <main>
        ');
    }

    //Método para imprimir el pie y establecer el controlador del documento
    public static function footerTemplate($controller) {
        print('
                </main>
                <!--Pie del documento-->
                <footer class="page-footer cyan darken-4">
                <div class="container">
                <div class="row">
                    <div class="col l6 s12">
                        <h5 class="white-text">Derechos de autor reservados para la compañia</h5>
                        <p class="grey-text text-lighten-4">Razon social:  Fitness Sports, s.a. de c.v

                        Número de identificación tributaria (NIT):  0114-900803-101-5
                        
                        Dirección: 9ª calle poniente #3935. Col. Escalon, San Salvador.
                        
                        © 2020 Fitness Sport | Fitnes_Sport.com.sv | Todos los derechos reservados.</p>
                    </div>
                    <div class="col l4 offset-l2 s12">
                        <h5 class="white-text">Nuestras redes sociales</h5>
                        <ul>
                        <li><a class="white-text" href="https://www.facebook.com/Fitness-Sport-106849218143648">Facebook</a><i class="material-icons left">facebook</i></li>                              
                        <li><a class="white-text" href="https://www.instagram.com/fitnesssport212/">Instagram</a><i class="material-icons left">phone_android</i></li>
                        <li><a class="white-text" href="https://twitter.com/Fitness24651901">Twitter</a><i class="material-icons left">people_outline</i></li> 
                        </ul>
                    </div>
                </div>
            </div>
                    <div class="footer-copyright">
                        <div class="container">
                            © 2014 Copyright Text
                            <a class="grey-text text-lighten-4 right" href="#!">More Links</a>
                        </div>
                    </div>
                </footer>
                <!--Importación de archivos JavaScript al final del cuerpo para una carga optimizada-->
                <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
                <script src="../../app/controllers/dashboard/'.$controller.'"></script>
            </body>
            </html>
        ');
    }
}
?>