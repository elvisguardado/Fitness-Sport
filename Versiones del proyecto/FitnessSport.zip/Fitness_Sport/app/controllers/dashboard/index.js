//Método que agrega un controlador de eventos cuando el contenido del documento ha sido cargado
document.addEventListener('DOMContentLoaded', function() {
    //Se declaran las variables necesarias para inicializar los componentes del framework
    let elements, instances;
    //Se inicializa el componente sidenav
    elements = document.querySelectorAll('.sidenav');
    instances = M.Sidenav.init(elements);

    $(document).ready(function() {
        $('input#input_text, textarea#textarea2').characterCounter();
      });

      document.addEventListener('DOMContentLoaded', function() {
        var elems = document.querySelectorAll('select');
        var instances = M.FormSelect.init(elems, options);
      });
    
      // Or with jQuery
    
      $(document).ready(function(){
        $('select').formSelect();
      });

      var instance = M.FormSelect.getInstance(elem);
      instance.getSelectedValues();

      document.addEventListener('DOMContentLoaded', function() {
        var elems = document.querySelectorAll('.datepicker');
        var instances = M.Datepicker.init(elems, options);
      });
    
      // Or with jQuery
    
      $(document).ready(function(){
        $('.datepicker').datepicker();
      });
      
});