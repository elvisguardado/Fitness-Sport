<?php
//Se incluye la clase con las plantillas del documento
include('../../app/helpers/admin_page_index.php');
//Se imprime la plantilla del encabezado y se envía el titulo para la página web
admin_page_index::headerTemplate('Bienvenido');
?>
<div class="section no-pad-bot" id="index-banner">
    <div class="container">
     <div class = "left form-box">

        <center><a href="" class="brand-logo"><img class="responsive-img" src="../../resources/img/g.png" width="600" height="600"></a></center>

        </div>
    </div>
    </div> 
    <div class="section no-pad-bot" id="index-banner">
    <div class="container">
     <div class = "left form-box">

        <center><a  href="" class="brand-logo"><img class="responsive-img" src="../../resources/img/g2.png" width="650" height="550"></a></center>

        </div>
    </div>
    </div> 
<?php
//Se imprime la plantilla del pie y se envía el nombre del controlador para la página web
admin_page_index::footerTemplate('index.js');
?>