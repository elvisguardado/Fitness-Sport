<?php
//Se incluye la clase con las plantillas del documento
include('../../app/helpers/public_page.php');
//Se imprime la plantilla del encabezado y se envía el titulo para la página web
Public_Page::headerTemplate('Bienvenido');
?>



<div class="section container">
  <div class="row">
    <form class="col12">
    <div class="row card-panel">

    <div class="image">
    <img class="left materialboxed responsive-img" width="600" height="600"src="https://www.futbolemotion.com/imagesarticulos/122314/grandes/balon-nike-strike-2018-2019-pure-platinum-wolf-grey-white-0.jpg">
</div>

     <div class="input-field col s6">
        <i class="material-icons prefix">face</i>
          <input placeholder="Escriba nombre" id="first_name" type="text" class="validate">
          <label for="first_name">Nombre</label>
      </div>

      <div class="input-field col s6">
        <i class="material-icons prefix">perm_contact_calendar</i>
          <input placeholder="Escriba Apellido" id="last_name" type="text" class="validate">
          <label for="last_name">Apellido</label>
      </div>

      <div class="input-field col s6">
        <i class="material-icons prefix">location_on</i>
          <input placeholder="Punto de referencia" id="Punto Referencia" type="text" class="validate">
          <label for="Phone_number">Punto referencia</label>
      </div>

        <div class="input-field col s6">
        <i class="material-icons prefix">hotel</i>
          <input placeholder="Direccion casa." id="Direccion" type="text" class="validate">
          <label for="Direccion">Direccion de la casa.</label>
        </div>
      

      <div class="input-field col s6">
          <input disabled value="Total a pagar: $20.0" id="disabled" type="text" class="validate"> 
          <label for="disabled">Precio</label>
      </div>

      <center><button class="btn-large waves-effect waves-light" type="submit" name="action">Ver<i class="material-icons left">check</i>Finalizar Compra</button></center>
      
      </div>
  </form>
  </div>
  </div>

    <script>
     document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.materialboxed');
    var instances = M.Materialbox.init(elems);
    });
    </script>
      
<?php
//Se imprime la plantilla del pie y se envía el nombre del controlador para la página web
Public_Page::footerTemplate('index.js');
?>