<?php
//Se incluye la clase con las plantillas del documento
include('../../app/helpers/public_page.php');
//Se imprime la plantilla del encabezado y se envía el titulo para la página web
Public_Page::headerTemplate('Bienvenido');
?>

<!--Primera card-->  
<div class="row">
  <div class="col s6 m4">
    <div class="card">
      <div class="card-image">
        <img class="responsive-img materialboxed" src="https://www.futbolemotion.com/imagesarticulos/122314/grandes/balon-nike-strike-2018-2019-pure-platinum-wolf-grey-white-0.jpg">
        <span class="card-title black-text">Pelota de Futbol</span>
        <a class="waves-effect waves-light btn modal-trigger" href="#modal1"><i class="material-icons">add</i></a>
      </div>
      <div class="card-content">
        <p>Pelota de futbol nike, copa america Merlin, roja, hombre.</p>
      </div>
    </div>
  </div>
  <!--Segunda card-->
  <div class="col s6 m4 ">
    <div class="card">
      <div class="card-image">
        <img class="responsive-img materialboxed" src="https://www.futbolemotion.com/imagesarticulos/117998/grandes/guante-sp-mussa-futsal-fingers-0.jpg">
        <span class="card-title black-text">Guantes</span>
        <a class="waves-effect waves-light btn modal-trigger" href="#modal2"><i class="material-icons">add</i></a>
      </div>
      <div class="card-content">
        <p>Guantes especiales para portero de fútbol, Guante Reusch Reusch Futsal SG SFX blue-Shocking</p>
      </div>
    </div>
  </div>
  <!--Tercera card-->
  <div class="col s6 m4 ">
    <div class="card">
      <div class="card-image">
        <img class="responsive-img materialboxed" src="https://www.futbolemotion.com/imagesarticulos/107765/grandes/tobillera-nike-hyperstrong-strike-black-1.jpg">
        <span class="card-title black-text">Rodilleras</span>
        <a class="waves-effect waves-light btn modal-trigger" href="#modal3"><i class="material-icons">add</i></a>
      </div>
      <div class="card-content">
        <p>Rodilleras deportivas de futbol nike, negras.</p>
      </div>
    </div>
  </div>
  <!--Cuarta card--> 
    <div class="col s6 m4">
      <div class="card">
        <div class="card-image">
          <img class="responsive-img materialboxed" src="https://www.floorballsupershop.com/5820-tm_large_default/red-para-porteria-de-floorball-iff.jpg">
          <span class="card-title black-text">Red de Porteria</span>
          <a class="waves-effect waves-light btn modal-trigger" href="#modal4"><i class="material-icons">add</i></a>
          </div>
          <div class="card-content">
          <p>Red para la porteria de futbol.</p>
        </div>
      </div>
    </div>
  </div> <!--Este es el final de la primer card-->

  <!-- Estructura del modal 1 -->
  <div id="modal1" class="modal">
    <div class="modal-content">
      <h4>Pelota de futbol</h4>
      <p>El balón de fútbol utilizado en competiciones oficiales es regulado en sus medidas por la FIFA. Tiene forma de icosaedro truncado en un 99.9%, una circunferencia entre 68 y 70 centímetros y un peso entre 410 y 450 gramos.</p>
      <p>Precio: 15.99$</p>
    </div>
    <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Comprar</a>
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Ok</a>
    </div>
  </div>
  <!-- Estructura del modal 2 -->
  <div id="modal2" class="modal">
    <div class="modal-content">
      <h4>Guantes</h4>
      <p>Todos los guantes de portero de las mejores marcas como SP, adidas, nike, Reusch, Uhlsport en la tienda para porteros mas grande del mundo</p>
      <p>Precio: 15.99$</p>
    </div>
    <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Comprar</a>
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Ok</a>
    </div>
  </div>
  <!-- Estructura del modal 3 -->
  <div id="modal3" class="modal">
    <div class="modal-content">
      <h4>Rodilleras</h4>
      <p>Todas las rodilleras de futbol de las mejores marcas como SP, adidas, nike, Reusch, Uhlsport en la tienda para accesorios mas grande del mundo</p>
      <p>Precio: 15.99$</p>
    </div>
    <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Comprar</a>
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Ok</a>
    </div>
  </div>
  <!-- Estructura del modal 4 -->
  <div id="modal4" class="modal">
    <div class="modal-content">
      <h4>Red de la porteria</h4>
      <p>Nuestras redes para porterías de fútbol cumplen con todos los requisitos de la norma UNE-EN 748</p>
      <p>Precio: 15.99$</p>
    </div>
    <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Comprar</a>
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Ok</a>
    </div>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<script>
     document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.materialboxed');
    var instances = M.Materialbox.init(elems);
  });
  </script>
<?php
//Se imprime la plantilla del pie y se envía el nombre del controlador para la página web
Public_Page::footerTemplate('index.js');
?>