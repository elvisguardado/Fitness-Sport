<?php
//Se incluye la clase con las plantillas del documento
include('../../app/helpers/public_page.php');
//Se imprime la plantilla del encabezado y se envía el titulo para la página web
Public_Page::headerTemplate('Bienvenido');
?>

<!--Primera card-->  
<div class="row">
  <div class="col s6 m4">
    <div class="card">
      <div class="card-image">
        <img class="responsive-img materialboxed" src="https://gympro01.akamaized.net/4424-thickbox_default/lentes-de-natacion-polarizado-rojo-four.jpg">
        <span class="card-title black-text">Lente de natación</span>
        <a class="waves-effect waves-light btn modal-trigger" href="#modal1"><i class="material-icons">add</i></a>
      </div>
      <div class="card-content">
        <p>Lentes de natacion negro con rojo, perfectos para ejercer el deporte de natación.</p>
      </div>
    </div>
  </div>
  <!--Segunda card-->
  <div class="col s6 m4 ">
    <div class="card">
      <div class="card-image">
        <img class="responsive-img materialboxed" src="https://sc04.alicdn.com/kf/HTB1w2teXz14K1Rjt_bXq6yYnXXag.jpg">
        <span class="card-title black-text">Tapones de oidos</span>
        <a class="waves-effect waves-light btn modal-trigger" href="#modal2"><i class="material-icons">add</i></a>
      </div>
      <div class="card-content">
        <p>Tapones de oidos, perfectos para que no te entre el agua.</p>
      </div>
    </div>
  </div>
  <!--Tercera card-->
  <div class="col s6 m4 ">
    <div class="card">
      <div class="card-image">
        <img class="responsive-img materialboxed" src="https://gympro03.akamaized.net/5328-thickbox_default/gorro-de-silicona-natacion-hydro.jpg">
        <span class="card-title black-text">Gorro de natación</span>
        <a class="waves-effect waves-light btn modal-trigger" href="#modal3"><i class="material-icons">add</i></a>
      </div>
      <div class="card-content">
        <p>Gorro de natación de diferentes colores y tamaños perfecto para no mojarse el pelo mientras nadamos.</p>
      </div>
    </div>
  </div>
  <!--Cuarta card--> 
  <div class="col s6 m4 ">
    <div class="card">
      <div class="card-image">
        <img class="responsive-img materialboxed" src="https://mister-mango.omni.la/ProductCatalog/Workspace.CWDQQL6GUIJMS/ProductCatalog.CX33GLCPKWUH2/1500x1500/CX33JUDYGVAYS.jpg">
        <span class="card-title black-text">Flotador de natación</span>
        <a class="waves-effect waves-light btn modal-trigger" href="#modal4"><i class="material-icons">add</i></a>
      </div>
      <div class="card-content">
        <p>Flotador de natación en forma de Cisne para niños y niñas perfecto para estar en una piscina..</p>
      </div>
    </div>
  </div>
  </div> <!--Este es el final de la primer card-->

  <!-- Estructura del modal 1 -->
  <div id="modal1" class="modal">
    <div class="modal-content">
      <h4>Lentes de natación</h4>
      <p>Sirve para cubrirse los ojos y poder ver bajo el agua.</p>
      <p>Precio: 15.99$</p>
    </div>
    <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Comprar</a>
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Ok</a>
    </div>
  </div>
  <!-- Estructura del modal 2 -->
  <div id="modal2" class="modal">
    <div class="modal-content">
      <h4>Tapones para los oidos</h4>
      <p>Perfecto para que no te entre agua en los oidos.</p>
      <p>Precio: 15.99$</p>
    </div>
    <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Comprar</a>
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Ok</a>
    </div>
  </div>
  <!-- Estructura del modal 3 -->
  <div id="modal3" class="modal">
    <div class="modal-content">
      <h4>Gorro de natacion</h4>
      <p>Perfecto para no mojarte el pelo</p>
      <p>Precio: 15.99$</p>
    </div>
    <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Comprar</a>
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Ok</a>
    </div>
  </div>
    <!-- Estructura del modal 4 -->
    <div id="modal4" class="modal">
    <div class="modal-content">
      <h4>Flotadores</h4>
      <p>Con nuestros flotadores nunca te hundiras.</p>
      <p>Precio: 15.99$</p>
    </div>
    <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Comprar</a>
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Ok</a>
    </div>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<script>
     document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.materialboxed');
    var instances = M.Materialbox.init(elems);
  });
  </script>

<?php
//Se imprime la plantilla del pie y se envía el nombre del controlador para la página web
Public_Page::footerTemplate('index.js');
?>