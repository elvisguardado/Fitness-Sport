<?php
//Se incluye la clase con las plantillas del documento
include('../../app/helpers/public_page.php');
//Se imprime la plantilla del encabezado y se envía el titulo para la página web
Public_Page::headerTemplate('Bienvenido');
?>

<!--Primera card-->  
<div class="row">
  <div class="col s6 m4">
    <div class="card">
      <div class="card-image">
        <img class="responsive-img materialboxed" src="https://cdn.shopify.com/s/files/1/0245/3687/5088/products/Morada_01_2000x.png?v=1587648457.jpg">
        <span class="card-title black-text" >Botella de Agua </span>
        <a class="waves-effect waves-light btn modal-trigger" href="#modal1"><i class="material-icons">add</i></a>
      </div>
      <div class="card-content">
        <p>Perfecta para llevar el agua y poder hidratarte en cualquier lugar.</p>
      </div>
    </div>
  </div>
  <!--Segunda card-->
  <div class="col s6 m4">
    <div class="card">
      <div class="card-image">
        <img class="responsive-img materialboxed" src="https://cdn.grupoelcorteingles.es/SGFM/dctm/MEDIA03/201804/03/00108447394845____1__640x640.jpg">
        <span class="card-title black-text"> Pesas</span>
        <a class="waves-effect waves-light btn modal-trigger" href="#modal1"><i class="material-icons">add</i></a>
      </div>
      <div class="card-content">
        <p>Mancuernas para ejercitar los musculos del cuerpo de 5kg.</p>
      </div>
    </div>
  </div>
  <!--Tercera card-->
  <div class="col s6 m4">
    <div class="card">
      <div class="card-image ">
        <img class="responsive-img materialboxed" src="https://lh3.googleusercontent.com/proxy/4cM4A4sSvg6vRRDPthRJzsZASsB1aRTETpdV4u5UwbvjHmkvp52z4k5mf6wynUIF8kcsHx1e66Qer7xE3KjvXJhbVrzS98GLUUEDxCLDGU6xaS_Ro0xvnzp5w33A2cmb47BmXNbX0kdTnMzqEuPh9ViTYvOKMDtrlTbWhQ">
        <span class="card-title black-text"> Infladores</span>
        <a class="waves-effect waves-light btn modal-trigger" href="#modal1"><i class="material-icons">add</i></a>
      </div>
      <div class="card-content">
        <p>Bomba de aire capaz de inflar las diferentes pelotas de nuestra tienda.</p>
      </div>
    </div>
  </div> <!--Este es el final de la primer card-->

  <!-- Estructura del modal 1 -->
  <div id="modal1" class="modal">
    <div class="modal-content">
      <h4>Botella</h4>
      <p>Botella perfecta para tener agua contigo.</p>
      <p>Precio: 15.99$</p>
    </div>
    <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Comprar</a>
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Ok</a>
    </div>
  </div>
  <!-- Estructura del modal 2 -->
  <div id="modal2" class="modal">
    <div class="modal-content">
      <h4>Pesas</h4>
      <p>Pesas perfectas para el ejercitamiento de los musculos</p>
      <p>Precio: 15.99$</p>
    </div>
    <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Comprar</a>
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Ok</a>
    </div>
  </div>
  <!-- Estructura del modal 3 -->
  <div id="modal3" class="modal">
    <div class="modal-content">
      <h4>Inflador de pelotas</h4>
      <p>Bomba de aire capaz de inflar las diferentes pelotas de nuestra tienda</p>
      <p>Precio: 15.99$</p>
    </div>
    <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Comprar</a>
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Ok</a>
    </div>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<script>
     document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.materialboxed');
    var instances = M.Materialbox.init(elems);
  });
  </script>

<?php
//Se imprime la plantilla del pie y se envía el nombre del controlador para la página web
Public_Page::footerTemplate('index.js');
?>