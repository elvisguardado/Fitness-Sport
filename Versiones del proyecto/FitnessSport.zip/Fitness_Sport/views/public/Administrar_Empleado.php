<?php
//Se incluye la clase con las plantillas del documento
include('../../app/helpers/admin_page_index.php');
//Se imprime la plantilla del encabezado y se envía el titulo para la página web
admin_page_index::headerTemplate('Bienvenido');
?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">

<br>
<div class="section container">
<div class="row">

  <form class="col12">

  <div class="row card-panel">

    <div class="input-field col s6">
          <i class="material-icons prefix">face</i>
          <input type="text" placeholder="Ingrese su Nombre" id="nombre">
          <label for="nombre">Nombre</label>
    </div>

    <div class="input-field col s6">
          <i class="material-icons prefix">perm_contact_calendar</i>
          <input type="text" placeholder="Ingrese su Nombre" id="nombre">
          <label for="nombre">Apellido</label>
    </div>

    <div class="input-field col s6">
          <i class="material-icons prefix">call</i>
          <input type="text" placeholder="Ingrese su Telefono" id="nombre">
          <label for="nombre">Telefono</label>
    </div>

    <div class="input-field col s6">
        <input type="text" class="datepicker">
        <label for="nombre">Fecha</label>
    </div>

    <div class="input-field col s6">
          <i class="material-icons prefix">mode_comment</i>
          <input type="text" placeholder="Ingrese su Dui" id="nombre">
          <label for="nombre">Dui</label>
    </div>

    <div class="input-field col s6">
    <select>
      <option value="" disabled selected>Seleccione su genero</option>
      <option value="1">Hombre</option>
      <option value="2">Mujer</option>
      <option value="3">Prefiero no decir</option>
      </select>
      <label>Genero</label>
    </div>

    <div class="input-field col s6">
        <i class="material-icons prefix">bubble_chart</i>
        <input placeholder="Escriba su codigo" id="Codigo" type="text" class="validate">
        <label for="Codigo">Codigo</label>
    </div>

    <div class="input-field col s6">
    <select>
      <option value="" disabled selected>Seleccione el estado</option>
      <option value="1">En servicio</option>
      <option value="2">Ausente</option>
      <option value="3">Dejando Pedido</option>
      </select>
      <label>Estado del empleado</label>
    </div>

    <center><button class="btn-large waves-effect teal darken-3" type="submit" name="action">Crear<i class="material-icons right">add_circle_outline</i></button>
        <button class="btn-large waves-effect light-blue darken-4" type="submit" name="action">Ver<i class="material-icons right">visibility</i></button>
        <button class="btn-large waves-effect orange lighten-2" type="submit" name="action">Actualizar<i class="material-icons right">cached</i></button>
        <button class="btn-large waves-effect red darken-2" type="submit" name="action">Eliminar<i class="material-icons right">delete</i></button></center>

  </div>
  </form>
  </div>
  </div>

<div class="section container">
  <div class="row">
    <form class="col12">
      <div class="row card-panel">

      <div class="row">
    <div class="container">
     <div class = "rigth form-box">

    <nav class=" blue-grey lighten-1">
    <div class="nav-wrapper">
      <form>
        <div class="input-field">
          <input id="search" type="search" required>
          <label class="label-icon" for="search"><i class="material-icons">search</i></label>
          <i class="material-icons">close</i>
        </div>
      </form>
    </div>
  </nav>

  <br>

        <table class="highlight responsive-table centered">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Telefono</th>
                <th>Fecha de nacimiento</th>
                <th>Dui</th>
                <th>Genero</th>
                <th>Codigo</th>
                <th>Estado Empleado</th>
            </tr>
        </thead>
        <tbody>
            <tr>
            <td>Elvis</td>
                <td>Guardado</td>
                <td>78902912</td>
                <td>11/03/2002</td>
                <td>932193113-1</td>
                <td>Masculino</td>
                <td>32139213</td>
                <td>En servicio</td>
            </tr>
            
            <tr>
            <td>Juan</td>
                <td>Apaneca</td>
                <td>79123135</td>
                <td>14/05/2006</td>
                <td>348942734-1</td>
                <td>Femenino</td>
                <td>32139213</td>
                <td>En servicio</td>
            </tr>
            <tr>
            <td>Ricardo</td>
                <td>Perez</td>
                <td>789781912</td>
                <td>11/03/1992</td>
                <td>313213131-1</td>
                <td>Masculino</td>
                <td>32139213</td>
                <td>Dejando Pedido</td>
            </tr>
        </tbody>
    </table>
    </div>
  </form>
  </div>
  </div>
        
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
  <script>document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.datepicker');
    var instances = M.Datepicker.init(elems);
  });
  </script>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('select');
    var instances = M.FormSelect.init(elems);
  });
  </script>
        

<?php
//Se imprime la plantilla del pie y se envía el nombre del controlador para la página web
admin_page_index::footerTemplate('index.js');
?>