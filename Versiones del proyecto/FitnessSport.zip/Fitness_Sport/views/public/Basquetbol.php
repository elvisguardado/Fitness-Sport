<?php
//Se incluye la clase con las plantillas del documento
include('../../app/helpers/public_page.php');
//Se imprime la plantilla del encabezado y se envía el titulo para la página web
Public_Page::headerTemplate('Bienvenido');
?>

<!--Primera card-->  
<div class="row">
<div class="col s6 m4 ">
    <div class="card">
      <div class="card-image">
        <img class="responsive-img materialboxed" src="https://www.mideporte.pe/wp-content/uploads/2019/07/pelotas-de-basquet_winstar_3_02.jpg">
        <span class="card-title black-text">Pelota de basquetbol</span>
        <a class="waves-effect waves-light btn modal-trigger" href="#modal2"><i class="material-icons">add</i></a>
      </div>
      <div class="card-content">
        <p>Pelota Basket Winstar N°7 Peso Medida Oficial .</p>
      </div>
    </div>
  </div>
  <!--Segunda card-->
  <div class="col s6 m4 ">
    <div class="card">
      <div class="card-image">
        <img class="responsive-img materialboxed" src="https://www.costco.com.mx/medias/sys_master/products/hba/h60/11038523097118.jpg">
        <span class="card-title black-text">Canasta de basquetbol</span>
        <a class="waves-effect waves-light btn modal-trigger" href="#modal2"><i class="material-icons">add</i></a>
      </div>
      <div class="card-content">
        <p>Canasta de basquetbol perfecta para jugar en casa con las medidas necesarias para entrenar y jugar.</p>
      </div>
    </div>
  </div>
  <!--Tercera card-->
  <div class="col s6 m4 ">
    <div class="card">
      <div class="card-image">
        <img class="responsive-img materialboxed" src="https://www.basketspirit.com/WebRoot/ce_es/Shops/268403/5C06/A5D5/F0FD/463C/4EBB/C0A8/190E/96C2/juego-redes-baloncesto-6mm-13582_ml.jpg">
        <span class="card-title black-text">Red de canasta de basqutbol</span>
        <a class="waves-effect waves-light btn modal-trigger" href="#modal3"><i class="material-icons">add</i></a>
      </div>
      <div class="card-content">
        <p>Red de Basquetbol.</p>
      </div>
    </div>
  </div>
  </div> <!--Este es el final de la primer card-->

  <!-- Estructura del modal 1 -->
  <div id="modal1" class="modal">
    <div class="modal-content">
      <h4>Pelota de Basquetbol</h4>
      <p>El balón de basquetbol utilizado en competiciones oficiales es regulado en sus medidas.</p>
      <p>Precio: 15.99$</p>
    </div>
    <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Comprar</a>
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Ok</a>
    </div>
  </div>
  <!-- Estructura del modal 2 -->
  <div id="modal2" class="modal">
    <div class="modal-content">
      <h4>Canasta de Basquetbol</h4>
      <p>Perfecta para poner en la pared de tu casa, facil para entrenar.</p>
      <p>Precio: 15.99$</p>
    </div>
    <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Comprar</a>
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Ok</a>
    </div>
  </div>
  <!-- Estructura del modal 3 -->
  <div id="modal3" class="modal">
    <div class="modal-content">
      <h4>Red de Basquetbol</h4>
      <p>Red deportiva para la canasta de Basquetbol</p>
      <p>Precio: 15.99$</p>
    </div>
    <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Comprar</a>
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Ok</a>
    </div>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<script>
     document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.materialboxed');
    var instances = M.Materialbox.init(elems);
  });
  </script>

<?php
//Se imprime la plantilla del pie y se envía el nombre del controlador para la página web
Public_Page::footerTemplate('index.js');
?>