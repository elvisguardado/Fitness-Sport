<?php
//Se incluye la clase con las plantillas del documento
include('../../app/helpers/admin_page_index.php');
//Se imprime la plantilla del encabezado y se envía el titulo para la página web
admin_page_index::headerTemplate('Bienvenido');
?>

<div class="section container">
  <div class="row">
    <form class="col12">
    <div class="row card-panel">

    <nav class=" blue-grey lighten-1">
        <div class="nav-wrapper">
        <form>
        <div class="input-field">
          <input id="search" type="search" required>
          <label class="label-icon" for="search"><i class="material-icons">search</i></label>
          <i class="material-icons">close</i>
        </div>
        </form>
        </div>
    </nav>

    <br>
    <br>
    <div class="row">
        <div class="container">
            <div class = " form-box">
            <center><button class="btn-large waves-effect teal darken-3" type="submit" name="action">Crear<i class="material-icons right">add_circle_outline</i></button>
            <button class="btn-large waves-effect light-blue darken-4" type="submit" name="action">Ver<i class="material-icons right">visibility</i></button>
            <button class="btn-large waves-effect orange lighten-2" type="submit" name="action">Actualizar<i class="material-icons right">cached</i></button>
            <button class="btn-large waves-effect red darken-2" type="submit" name="action">Eliminar<i class="material-icons right">delete</i></button></center>
            </div>
        </div>
    </div>

    <table class="highlight responsive-table centered">
        <thead>
            <tr>
                <th>Fecha Ingreso</th>
                <th>Cantidad</th>
                <th>Producto</th>
                <th>Empleado</th>
            </tr>
        </thead>
        <tbody>
            <tr>
            <td>03/02/2021</td>
                <td>25</td>
                <td>Pelotas de Tenis</td>
                <td>Elvis</td>
            </tr>
            <tr>
            <td>03/05/2021</td>
                <td>50</td>
                <td>Redes de Futbol</td>
                <td>Wilber</td>
            </tr>
            <tr>
            <td>06/07/2021</td>
                <td>100</td>
                <td>Casco de beisbol</td>
                <td>Andrea</td>
            </tr>
        </tbody>
    </table>
    <br>
    <br>

    </div>
  </form>
  </div>
</div>
 

<?php
//Se imprime la plantilla del pie y se envía el nombre del controlador para la página web
admin_page_index::footerTemplate('index.js');
?>