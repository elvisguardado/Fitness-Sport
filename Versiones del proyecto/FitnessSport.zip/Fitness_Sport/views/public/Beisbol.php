<?php
//Se incluye la clase con las plantillas del documento
include('../../app/helpers/public_page.php');
//Se imprime la plantilla del encabezado y se envía el titulo para la página web
Public_Page::headerTemplate('Bienvenido');
?>

<!--Primera card-->  
<div class="row">
  <div class="col s6 m4">
    <div class="card">
      <div class="card-image">
        <img class="responsive-img materialboxed" src="https://contents.mediadecathlon.com/p1571953/k$b0ad6de0007415557d5dbd1378dc91cb/bate-de-beisbol-de-madera-ba150-30-33-pul.jpg?&f=800x800.jpg">
        <span class="card-title black-text">Bate de béisbol</span>
        <a class="waves-effect waves-light btn modal-trigger" href="#modal1"><i class="material-icons">add</i></a>
        </div>
        <div class="card-content">
        <p>Bates de Béisbol. #1. Rawlings Raptor.</p>
      </div>
    </div>
  </div>


  <!--Segunda card-->
  <div class="col s6 m4 ">
    <div class="card">
      <div class="card-image">
        <img class="responsive-img materialboxed" src="https://www.soyvisual.org/sites/default/files/styles/twitter_card/public/images/photos/dep_0027.jpg?itok=ug5o7ctn">
        <span class="card-title black-text">Pelota de béisbol</span>
        <a class="waves-effect waves-light btn modal-trigger" href="#modal2"><i class="material-icons">add</i></a>
        </div>
        <div class="card-content">
        <p>Con nuestras pelotas de beisbol siempre ganaras los partidos.</p>
      </div>
    </div>
  </div>


  <!--Tercera card-->
  <div class="col s6 m4 ">
    <div class="card">
      <div class="card-image">
        <img class="responsive-img materialboxed" src="https://contents.mediadecathlon.com/p1571851/k$960bcad1c42b6068d9832835a7b0fce6/sq/Guante+de+b+isbol+A700+mano+izquierda+12+pulgadas+beige.jpg">
        <span class="card-title black-text">Guantes de béisbol</span>
        <a class="waves-effect waves-light btn modal-trigger" href="#modal3"><i class="material-icons">add</i></a>
        </div>
        <div class="card-content">
        <p>Guantes de béisbol utilizado para proteger la mano.</p>
      </div>
    </div>
  </div>


  <!--Cuarta card--> 
  <div class="col s6 m4 ">
    <div class="card">
      <div class="card-image">
        <img class="responsive-img materialboxed" src="https://martimx.vteximg.com.br/arquivos/ids/531873-720-720/1127877086-4.png?v=637425452556630000">
        <span class="card-title black-text">Casco de beisbol</span>
        <a class="waves-effect waves-light btn modal-trigger" href="#modal4"><i class="material-icons">add</i></a>
        </div>
        <div class="card-content">
        <p>Casco de beisbol llevada por los bateadores perfectos para proteger la cabeza.</p>
      </div>
    </div>
  </div>


    <!--Quinta card--> 
    <div class="col s6 m4">
      <div class="card">
        <div class="card-image">
          <img class="responsive-img materialboxed" src="http://cdn.shopify.com/s/files/1/0060/9019/5044/products/nike-bat-accessories-adult-bpg-40-20-leg-guard_1200x1200.jpg?v=1576249498">
          <span class="card-title black-text">Rodillera de beisbol</span>
          <a class="waves-effect waves-light btn modal-trigger" href="#modal5"><i class="material-icons">add</i></a>
          </div>
          <div class="card-content">
          <p>Con nuestras rodilleras de beisbol nunca te lastimaras en las barridas.</p>
        </div>
      </div>
    </div>
  </div> <!--Este es el final de la primer card-->

  <!-- Estructura del modal 1 -->
  <div id="modal1" class="modal">
    <div class="modal-content">
      <h4>Bate de beisbol</h4>
      <p>Bate de besibol de madera.</p>
      <p>Precio: 15.99$</p>
      </div>
      <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Comprar</a>
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Ok</a>
    </div>
  </div>


  <!-- Estructura del modal 2 -->
  <div id="modal2" class="modal">
    <div class="modal-content">
      <h4>Pelota de beisbol</h4>
      <p>Con esta pelota ganaras todos tus partidos.</p>
      <p>Precio: 15.99$</p>
      </div>
      <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Comprar</a>
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Ok</a>
    </div>
  </div>


  <!-- Estructura del modal 3 -->
  <div id="modal3" class="modal">
    <div class="modal-content">
      <h4>Guantes de beisbol</h4>
      <p>Con nuestros guantes de beisbol siempre atraparas las pelotas.</p>
      <p>Precio: 15.99$</p>
      </div>
      <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Comprar</a>
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Ok</a>
    </div>
  </div>


  <!-- Estructura del modal 4 -->
  <div id="modal4" class="modal">
    <div class="modal-content">
      <h4>Casco</h4>
      <p>Nuestros cascos te protegen de los golpes.</p>
      <p>Precio: 15.99$</p>
      </div>
      <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Comprar</a>
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Ok</a>
    </div>
  </div>


  <!-- Estructura del modal 5 -->
    <div id="modal5" class="modal">
    <div class="modal-content">
      <h4>Tobilleras de proteción para los pies</h4>
      <p>Nuestras tobilleras son las mejores para protegerte.</p>
      <p>Precio: 15.99$</p>
      </div>
      <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Comprar</a>
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Ok</a>
    </div>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
  <script>
     document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.materialboxed');
    var instances = M.Materialbox.init(elems);
  });
  </script>

<?php
//Se imprime la plantilla del pie y se envía el nombre del controlador para la página web
Public_Page::footerTemplate('index.js');
?>