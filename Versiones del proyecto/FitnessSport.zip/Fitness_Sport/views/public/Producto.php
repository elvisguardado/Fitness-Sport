<?php
//Se incluye la clase con las plantillas del documento
include('../../app/helpers/admin_page_index.php');
//Se imprime la plantilla del encabezado y se envía el titulo para la página web
admin_page_index::headerTemplate('Bienvenido');
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">


<br>
<div class="section container">
  <div class="row">
    <form class="col12">
    <div class="row card-panel">

    <div class="input-field col s6">
          <i class="material-icons prefix">local_grocery_store</i>
          <input placeholder="Nombre del producto" id="first_name" type="text" class="validate">
          <label for="first_name">Nombre Producto</label>
    </div>

    <div class="input-field col s6">
        <i class="material-icons prefix">message</i>
          <input placeholder="Descripcion" id="last_name" type="text" class="validate">
          <label for="last_name">Descripcion</label>
    </div>

    <div class="input-field col s6">
        <select>
          <option value="" disabled selected>Seleccione el estado.</option>
          <option value="1">Nuevo</option>
          <option value="2">En oferta</option>
          <option value="3">Mas vendido</option>
        </select>
        <label>Estado Producto</label>
    </div>

    <div class="input-field col s6">
          <i class="material-icons prefix">monetization_on</i>
          <input placeholder="Precio del producto" id="Fecha Nacimiento" type="tel" class="validate">
          <label for="Fecha Nacimiento">Precio</label>
    </div>

    <div class="input-field col s6">
        <select>
          <option value="" disabled selected>Seleccione la marca.</option>
          <option value="1">Brazileiro</option>
          <option value="2">Jordan</option>
          <option value="3">Brazileiro</option>
        </select>
        <label>Marca de Producto</label>
    </div>

    <div class="input-field col s6">
        <form action="#">
          <div class="file-field input-field">
          <div class="btn">
          <span>Imagen</span>
          <input type="file">
          </div>
          <div class="file-path-wrapper">
          <input class="file-path validate" type="text">
          </div>
          </div>
        </form>
    </div>

        <center><button class="btn-large waves-effect teal darken-3" type="submit" name="action">Crear<i class="material-icons right">add_circle_outline</i></button>
        <button class="btn-large waves-effect light-blue darken-4" type="submit" name="action">Ver<i class="material-icons right">visibility</i></button>
        <button class="btn-large waves-effect orange lighten-2" type="submit" name="action">Actualizar<i class="material-icons right">cached</i></button>
        <button class="btn-large waves-effect red darken-2" type="submit" name="action">Eliminar<i class="material-icons right">delete</i></button></center>

    </div>
  </form>
</div>
</div>

<div class="section container">
  <div class="row">
    <form class="col12">
    <div class="row card-panel">  
        
    <nav class=" blue-grey lighten-1">
    <div class="nav-wrapper">
      <form>
        <div class="input-field">
          <input id="search" type="search" required>
          <label class="label-icon" for="search"><i class="material-icons">search</i></label>
          <i class="material-icons">close</i>
        </div>
      </form>
    </div>
  </nav>
        <br>
    <table class="highlight responsive-table centered">
        <thead>
            <tr>
                <th>Producto</th>
                <th>Descripcion</th>
                <th>Estado</th>
                <th>Precio</th>
                <th>Marca</th>
                <th>Imagen</th>
            </tr>
        </thead>
        <tbody>
            <tr>
            <td>Pelota de futbol</td>
                <td>Una pelota bonita</td>
                <td>Nuevo</td>
                <td>25.0</td>
                <td>Nike</td>
                <td><img src="https://www.futbolemotion.com/imagesarticulos/122314/grandes/balon-nike-strike-2018-2019-pure-platinum-wolf-grey-white-0.jpg" height="85" width="85"></td>
            </tr>
            <tr>
            <td>Tobillera</td>
                <td>Duradera</td>
                <td>En oferta</td>
                <td>14.99</td>
                <td>Jordan</td>
                <td><img src="https://www.futbolemotion.com/imagesarticulos/107765/grandes/tobillera-nike-hyperstrong-strike-black-1.jpg" height="85" width="85"></td>
                
            </tr>
            <tr>
            <td>Bate de beisbol</td>
                <td>Que duro esta</td>
                <td>Mas vendido</td>
                <td>50.0</td>
                <td>Brazileiro</td>
                <td><img src="https://contents.mediadecathlon.com/p1571953/k$b0ad6de0007415557d5dbd1378dc91cb/bate-de-beisbol-de-madera-ba150-30-33-pul.jpg?&f=800x800.jpg" height="85" width="85"></td>
                
            </tr>
        </tbody>
    </table>
    <br>
    <br>

    </div>
  </form>
</div>
</div>
        
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('select');
    var instances = M.FormSelect.init(elems);
  });
  </script>
        

<?php
//Se imprime la plantilla del pie y se envía el nombre del controlador para la página web
admin_page_index::footerTemplate('index.js');
?>